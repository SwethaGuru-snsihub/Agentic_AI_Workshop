import os
import streamlit as st
import google.generativeai as genai
from sentence_transformers import SentenceTransformer
import faiss
import PyPDF2
import re
from typing import List, Dict
from dotenv import load_dotenv


# Load environment variables from .env file
load_dotenv()

class RAGSystem:
    def __init__(self, api_key: str, papers_dir: str = "papers"):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')
        self.encoder = SentenceTransformer('all-MiniLM-L6-v2')
        self.papers_dir = papers_dir
        self.chunks = []
        self.index = None
        self.initialized = False

    def _load_pdf(self, file_path: str) -> str:
        try:
            with open(file_path, 'rb') as file:
                text = "".join(page.extract_text() for page in PyPDF2.PdfReader(file).pages)
                return re.sub(r'\s+', ' ', re.sub(r'[^\w\s.,!?;:()\-]', '', text)).strip()
        except Exception as e:
            st.error(f"Error loading {file_path}: {e}")
            return ""

    def _load_pdf_from_bytes(self, file_bytes, filename: str) -> str:
        """Load PDF from uploaded file bytes"""
        try:
            pdf_reader = PyPDF2.PdfReader(file_bytes)
            text = "".join(page.extract_text() for page in pdf_reader.pages)
            return re.sub(r'\s+', ' ', re.sub(r'[^\w\s.,!?;:()\-]', '', text)).strip()
        except Exception as e:
            st.error(f"Error loading uploaded file {filename}: {e}")
            return ""

    def _chunk_text(self, text: str, source: str, size: int = 1000, overlap: int = 200) -> List[Dict]:
        words = text.split()
        return [
            {
                'text': ' '.join(words[i:i + size]),
                'source': source,
                'chunk_id': f"{source}_chunk_{i // (size - overlap)}"
            }
            for i in range(0, len(words), size - overlap)
        ]

    def initialize(self, uploaded_files=None) -> bool:
        # Process directory files first (existing functionality)
        directory_files = []
        if os.path.exists(self.papers_dir):
            directory_files = [f for f in os.listdir(self.papers_dir) if f.endswith('.pdf')]
        
        # Check if we have either directory files or uploaded files
        if not directory_files and not uploaded_files:
            st.error("📄 No PDF files found! Please add research papers to the directory or upload files.")
            return False

        # Enhanced progress tracking
        total_files = len(directory_files) + (len(uploaded_files) if uploaded_files else 0)
        progress_bar = st.progress(0)
        status_text = st.empty()
        self.chunks = []
        current_file = 0

        # Process directory files (existing functionality)
        for filename in directory_files:
            current_file += 1
            progress_bar.progress(current_file / total_files)
            status_text.text(f"📖 Processing {filename}... ({current_file}/{total_files})")
            
            text = self._load_pdf(os.path.join(self.papers_dir, filename))
            if text:
                self.chunks.extend(self._chunk_text(text, filename))

        # Process uploaded files (new functionality)
        if uploaded_files:
            for uploaded_file in uploaded_files:
                current_file += 1
                progress_bar.progress(current_file / total_files)
                status_text.text(f"📤 Processing uploaded {uploaded_file.name}... ({current_file}/{total_files})")
                
                text = self._load_pdf_from_bytes(uploaded_file, uploaded_file.name)
                if text:
                    self.chunks.extend(self._chunk_text(text, f"📤 {uploaded_file.name}"))

        if not self.chunks:
            status_text.empty()
            progress_bar.empty()
            return False

        status_text.text("🧠 Creating embeddings...")
        embeddings = self.encoder.encode([chunk['text'] for chunk in self.chunks])

        self.index = faiss.IndexFlatIP(embeddings.shape[1])
        faiss.normalize_L2(embeddings)
        self.index.add(embeddings.astype('float32'))

        self.initialized = True
        progress_bar.empty()
        status_text.empty()
        st.balloons()  # Celebration animation
        return True

    def ask(self, question: str, k: int = 3) -> Dict:
        if not self.initialized:
            return {'answer': "❌ System not initialized", 'sources': []}

        query_emb = self.encoder.encode([question])
        faiss.normalize_L2(query_emb)
        scores, indices = self.index.search(query_emb.astype('float32'), k)

        if indices[0][0] == -1:
            return {'answer': "❌ No relevant information found", 'sources': []}

        context_parts = []
        sources = []

        for score, idx in zip(scores[0], indices[0]):
            if idx != -1:
                chunk = self.chunks[idx]
                context_parts.append(f"Source: {chunk['source']}\n{chunk['text']}")
                sources.append({
                    'source': chunk['source'],
                    'score': float(score),
                    'preview': chunk['text'][:200] + "..."
                })

        context = "\n\n---\n\n".join(context_parts)

        prompt = f"""Based on the AI research papers context below, provide a comprehensive answer.

Context: {context}

Question: {question}

Instructions: Reference specific papers, use technical terms appropriately, and structure clearly.
"""

        try:
            answer = self.model.generate_content(prompt).text
        except Exception as e:
            answer = f"❌ Error generating answer: {e}"

        return {'answer': answer, 'sources': sources, 'context': context}


def main():
    # Enhanced page configuration
    st.set_page_config(
        page_title="RAG QA SYSTEM",
        page_icon="🤖",
        layout="wide",
        initial_sidebar_state="collapsed"
    )

    # Custom CSS for better styling
    st.markdown("""
    <style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2.5rem 2rem;
        border-radius: 15px;
        margin-bottom: 2rem;
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    }
    .setup-card {
        background: #ffffff;
        padding: 2rem;
        border-radius: 15px;
        border: 1px solid #e0e6ed;
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
        margin-bottom: 2rem;
    }
    .upload-card {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 12px;
        border: 2px dashed #dee2e6;
        margin: 1rem 0;
        text-align: center;
    }
    .answer-box {
        background: linear-gradient(135deg, #f8fffe 0%, #f0fff4 100%);
        padding: 2rem;
        border-radius: 15px;
        border-left: 6px solid #10b981;
        margin: 1.5rem 0;
        box-shadow: 0 4px 20px rgba(16, 185, 129, 0.1);
        color: black;
    }
    .sample-questions {
        background: #f8fafc;
        padding: 1.5rem;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        margin-top: 1rem;
    }
    .question-item {
        background: white;
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 8px;
        border-left: 4px solid #3b82f6;
        cursor: pointer;
        transition: all 0.3s ease;
        color: black;
    }
    .question-item:hover {
        background: #f1f5f9;
        transform: translateX(5px);
    }
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        text-align: center;
        border: 1px solid #e5e7eb;
    }
    .stButton > button {
        border-radius: 25px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    .stTextArea > div > div > textarea {
        border-radius: 15px;
        border: 2px solid #e5e7eb;
        font-size: 16px;
    }
    .stTextArea > div > div > textarea:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    </style>
    """, unsafe_allow_html=True)

    # Enhanced header
    st.markdown("""
    <div class="main-header">
        <h1 style="color: white; text-align: center; margin: 0; font-size: 2.5rem; font-weight: 700;">
            🤖 QA Assistant
        </h1>
        <p style="color: white; text-align: center; margin: 1rem 0 0 0; font-size: 1.2rem; opacity: 0.95;">
            Get instant, intelligent answers from your research papers using advanced RAG technology
        </p>
    </div>
    """, unsafe_allow_html=True)

    # Setup section
    if 'rag_system' not in st.session_state:
        st.markdown("""
        <div class="setup-card">
            <h2 style="color: #1f2937; margin-bottom: 1rem;">🚀 Quick Setup</h2>
            <p style="color: #6b7280; margin-bottom: 1.5rem;">
                Initialize your AI assistant by specifying where your research papers are stored or upload PDF files directly.
            </p>
        </div>
        """, unsafe_allow_html=True)

        # Setup form
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            papers_dir = st.text_input(
                "📁 Papers Directory Path",
                value="papers",
                help="Directory containing your PDF research papers",
                placeholder="Enter the path to your papers folder..."
            )
        
        with col2:
            st.write("")  # Spacing
            st.write("")  # Spacing
            
        with col3:
            st.write("")  # Spacing
            st.write("")  # Spacing

        # File upload section (NEW FUNCTIONALITY)
        st.markdown("""
        <div class="upload-card">
            <h4 style="color: #374151; margin-bottom: 0.5rem;">📤 Or Upload PDF Files</h4>
            <p style="color: #6b7280; margin-bottom: 1rem; font-size: 0.9rem;">
                You can upload PDF research papers directly instead of using a directory
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        uploaded_files = st.file_uploader(
            "Choose PDF files",
            type="pdf",
            accept_multiple_files=True,
            help="Upload one or more PDF research papers"
        )

        if uploaded_files:
            st.success(f"📄 {len(uploaded_files)} file(s) uploaded successfully!")
            for file in uploaded_files:
                st.write(f"• {file.name} ({file.size} bytes)")

        # Initialize button
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            init_btn = st.button(
                "🚀 Initialize System",
                type="primary",
                use_container_width=True,
                help="Start processing your research papers"
            )

        api_key = os.getenv("GEMINI_API_KEY", "")

        if init_btn:
            if not api_key:
                st.error("🔑 Please set your Gemini API key in the .env file")
                st.info("💡 Create a .env file with: GEMINI_API_KEY=your_api_key_here")
            elif not os.path.exists(papers_dir) and not uploaded_files:
                st.error(f"📁 Directory '{papers_dir}' not found and no files uploaded!")
                st.info(f"💡 Either create the directory with PDF files or upload PDF files above.")
            else:
                with st.spinner("🔄 Initializing your AI assistant..."):
                    st.session_state.rag_system = RAGSystem(api_key, papers_dir)
                    if st.session_state.rag_system.initialize(uploaded_files):
                        st.success("✅ System ready! You can now ask questions.")
                        st.rerun()

        # Enhanced sample questions
        st.markdown("""
        <div class="sample-questions">
            <h3 style="color: #1f2937; margin-bottom: 1rem;">💡 Sample Questions to Get Started (Papers Folder)</h3>
            <p style="color: #6b7280; margin-bottom: 1rem;">
                Try these questions once your system is initialized:
            </p>
        </div>
        """, unsafe_allow_html=True)

        sample_questions = [
            "What are the main components of a RAG model, and how do they interact?",
            "What are the two sub-layers in each encoder layer of the Transformer model?",
            "Explain how positional encoding is implemented in Transformers and why it is necessary.",
            "What is Generative AI (GenAI), and how does it work?",
            "What is few-shot learning, and how does GPT-3 implement it during inference?"
        ]

        for i, question in enumerate(sample_questions, 1):
            st.markdown(f"""
            <div class="question-item">
                <strong style="color: #3b82f6;">Q{i}:</strong> {question}
            </div>
            """, unsafe_allow_html=True)

        # Instructions
        with st.expander("📖 How to Use This System", expanded=False):
            st.markdown("""
            ### 🔧 Setup Steps:
            1. **Prepare Papers**: Add your PDF research papers to the specified directory OR upload files directly
            2. **Set API Key**: Add your Gemini API key to a .env file
            3. **Initialize**: Click the "Initialize System" button
            4. **Ask Questions**: Start asking intelligent questions about your papers!

            ### 📁 Supported Formats:
            - PDF research papers
            - Academic journals
            - Conference proceedings
            - Technical reports

            ### 📤 Upload Options:
            - **Directory**: Place PDF files in the specified folder
            - **Upload**: Use the file uploader to upload PDFs directly
            - **Both**: You can use both methods together

            ### 🎯 Best Practices:
            - Use specific, technical questions for better results
            - Reference specific concepts or methodologies
            - Ask about comparisons between different approaches
            """)

    else:
        # Main Q&A interface
        st.markdown("### 💬 Ask Your Research Question")
        
        # System status
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown("""
            <div class="metric-card">
                <h4 style="color: #10b981; margin: 0;">✅ System Ready</h4>
                <p style="margin: 0; color: #6b7280;">AI Assistant Online</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            papers_count = len(set(chunk['source'] for chunk in st.session_state.rag_system.chunks))
            st.markdown(f"""
            <div class="metric-card">
                <h4 style="color: #3b82f6; margin: 0;">📚 {papers_count} Papers</h4>
                <p style="margin: 0; color: #6b7280;">Ready for Questions</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            chunks_count = len(st.session_state.rag_system.chunks)
            st.markdown(f"""
            <div class="metric-card">
                <h4 style="color: #8b5cf6; margin: 0;">🧩 {chunks_count} Chunks</h4>
                <p style="margin: 0; color: #6b7280;">Knowledge Base</p>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Enhanced question input
        question = st.text_area(
            "🔍 What would you like to know about your research papers?",
            height=120,
            placeholder="Example: How do transformer models handle long sequences?\n\nAsk about specific concepts, methodologies, comparisons, or technical details...",
            help="Be specific and technical for the best results!"
        )

        # Action buttons
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            ask_btn = st.button(
                "🔍 Get AI Answer",
                type="primary",
                use_container_width=True,
                disabled=not question.strip(),
                help="Generate intelligent answer from your research papers"
            )

        if ask_btn and question.strip():
            with st.spinner("🧠 Analyzing papers and generating answer..."):
                result = st.session_state.rag_system.ask(question)

            # Enhanced answer display
            st.markdown("### 💡 AI Generated Answer")
            st.markdown(f"""
            <div class="answer-box">
                {result['answer'].replace('\n', '<br>')}
            </div>
            """, unsafe_allow_html=True)

            # Enhanced sources display
            if result['sources']:
                st.markdown("### 📚 Source References")
                
                for i, source in enumerate(result['sources'], 1):
                    relevance_color = "#10b981" if source['score'] > 0.7 else "#f59e0b" if source['score'] > 0.5 else "#ffffff"
                    
                    with st.expander(
                        f"📄 **{source['source']}** (Relevance: {source['score']:.1%})",
                        expanded=i == 1
                    ):
                        st.markdown(f"""
                        <div style="background: #00CAFF; padding: 1rem; border-radius: 8px; border-left: 3px solid {relevance_color};">
                            <strong>Source Extract:</strong><br>
                            {source['preview']}
                        </div>
                        """, unsafe_allow_html=True)

        # Enhanced footer actions
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col1:
            if st.button("🔄 Reset System", type="secondary", help="Clear system and start over"):
                del st.session_state.rag_system
                st.rerun()
        
        with col3:
            if st.button("ℹ️ System Info", help="View system details"):
                # Show which sources are from directory vs uploaded
                directory_sources = [chunk['source'] for chunk in st.session_state.rag_system.chunks if not chunk['source'].startswith('📤')]
                uploaded_sources = [chunk['source'] for chunk in st.session_state.rag_system.chunks if chunk['source'].startswith('📤')]
                
                st.info(f"""
                **System Information:**
                - Papers Loaded: {len(set(chunk['source'] for chunk in st.session_state.rag_system.chunks))}
                - From Directory: {len(set(directory_sources))}
                - From Upload: {len(set(uploaded_sources))}
                - Total Chunks: {len(st.session_state.rag_system.chunks)}
                - Model: Gemini 1.5 Flash
                - Embeddings: all-MiniLM-L6-v2
                """)

if __name__ == "__main__":
    main()